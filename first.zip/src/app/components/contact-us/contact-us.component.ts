import { Component } from '@angular/core';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrl: './contact-us.component.scss'
})
export class ContactUsComponent {
  phNo = "+91 9724634401";
  email = "dhyeymistri27&#64;gmail.com"
}
