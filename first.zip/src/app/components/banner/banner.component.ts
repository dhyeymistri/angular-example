import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-banner',
  templateUrl: './banner.component.html',
  styleUrl: './banner.component.scss'
})
export class BannerComponent implements OnInit {
  showCart:boolean=false
  loginText:string=""
  ngOnInit(): void {
    if(this.userService.checkLogin()){
      this.showCart=true
      this.loginText="Logout"
    } else{
      this.loginText="Login"
    }
} 
constructor(private userService: UserService){

}
}
