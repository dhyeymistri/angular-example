export class Category{
    categoryId: number
    catDescription: string

    constructor(id:number, desc:string){
        this.categoryId = id
        this.catDescription = desc
    }
}