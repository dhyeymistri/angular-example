export class Faculty{
    facultyId: number
    facultyUserId: number

    constructor(id:number, userId:number){
        this.facultyId = id
        this.facultyUserId = userId
    }
}