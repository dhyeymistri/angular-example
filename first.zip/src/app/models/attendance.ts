export class Attendance{
    courseID: number
    traineeID: number

    constructor(cid:number, tid:number){
        this.courseID = cid
        this.traineeID = tid
    }
}