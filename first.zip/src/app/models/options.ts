export class options{
    id:string
    optName:string

    constructor(id:string, optN:string){
        this.id = id
        this.optName = optN
    }
}