export class Trainee{
    traineeId: number
    traineeUserId: number

    constructor(id:number, userId:number){
        this.traineeId = id
        this.traineeUserId = userId
    }
}